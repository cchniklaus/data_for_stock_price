import datetime
a=datetime.datetime.now()

import psutil
# 处理如何使用cbam的问题。
# 基础库
import pandas as pd
import numpy as np

# 用于画图
import matplotlib.pyplot as plt

# 用于搭建网络
import tensorflow as tf
from keras.models import *
from keras.layers import *
from keras.optimizers import *

# 用于评价模型
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 用于复现
import random as rn

# 消除警告
import warnings

warnings.filterwarnings("ignore")

from sklearn.metrics import mean_absolute_error  # MAE
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
import os
import CBAM1D
from keras import backend


def repetition(x=123, y=12345, z=1234):
    np.random.seed(x)
    rn.seed(y)
    session_conf = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
    tf.random.set_seed(z)
    sess = tf.compat.v1.Session(graph=tf.compat.v1.get_default_graph(), config=session_conf)
    tf.compat.v1.keras.backend.set_session(sess)
    return None


data = pd.read_csv('eng/STI.csv')# 获取数据
# 计划使用2000个数据，时间截止到2020-08-31，经过计算对应的index分别为6445到8444，所以需要使用8445
data1 = data['收盘价'].iloc[6445:8445]
print(len(data1))# 获取目标数据成功。
# 判断data1中是否有nan
data1[data1.isnull() == True]
# 删除缺失值
data1 = data1.dropna()

x_max = data1.max()
x_min = data1.min()
data3 = (data1 - x_min) / (x_max - x_min)

# 选择使用60预测1，所以先将数据转化成这个样子
def transform_data(data, dim_x, dim_y=1):
    """
    data:需要使用list输入
    dim_x:顾名思义
    dim_y:顾名思义，默认为1
    return:经过转化之后的数据
    """
    x, y = [], []
    # 首先计算经过转化之后的样本个数
    # 一个样本的长度是dim_x+dim_y，但是数据是从0开始的，所以相差的距离是dim_x+dim_y-1
    index_n_samples = len(data) - 1 - (dim_x + dim_y - 1)  # len(data)-1表示最后一个元素的index
    # 如此方能计算出样本数的索引index
    for i in range(index_n_samples + 1):
        # range中的最后一个元素取不到，所以加1
        x.append(data[0 + i:dim_x + i])
        y.append(data[dim_x + i:dim_x + dim_y + i])
    # 如此方能完成转化
    return (x, y)

def network_bilstm_cbams_shang(a_input, n):
    # n表示cbam的个数。
    if n==0:
        a1 = Bidirectional(LSTM(64, use_bias=True, return_sequences=False))(a_input)
        a5 = Dense(1)(a1)
    else:
        cbam = CBAM1D.cbam_module(a_input)
        if n > 1:
            for _ in range(n - 1):
                cbam = CBAM1D.cbam_module(cbam)
        a1 = Bidirectional(LSTM(64, use_bias=True, return_sequences=False))(cbam)
        a5 = Dense(1)(a1)
    return a5



x, y = transform_data(data3.to_list(), 30)
# 划分成训练集，验证集，测试集
train_x, valida_x, test_x = x[:-400], x[-400:-200], x[-200:]
train_y, valida_y, test_y = y[:-400], y[-400:-200], y[-200:]

"""
测试不同的分解算法
"""
from PyEMD import EEMD, CEEMDAN
eemd=CEEMDAN()
eemd.ceemdan(np.array(data3))
imfs,res=eemd.get_imfs_and_residue()
allimfs=np.concatenate([imfs,res.reshape((1,-1))],axis=0)

"""
import vmdpy

# VDM参数
alpha = 60 * 2  # alpha和子序列个数k是相互配合使用的，需要找寻自适应求解超参数的算法
tau = 0  # 分量和与总量的差距
#K = 8  # 指定分解个数
DC = 0  # 指定第一个是趋势项
init = 1  # 指定均匀分布初始化
tol = 1e-7  # 误差阈值
K=10
(u, u_hat, omega) = vmdpy.VMD(data3.to_list(), alpha, tau, K, DC, init, tol)
"""
n=3

seq = []
for i in range(allimfs.shape[0]):
    seq.append(allimfs[i])
x_and_y=[transform_data(j,30) for j in seq]

trainX=[m[0][:-400] for m in x_and_y]
validaX=[m[0][-400:-200] for m in x_and_y]
testX=[m[0][-200:] for m in x_and_y]

trainY=[m[1][:-400] for m in x_and_y]
validaY=[m[1][-400:-200] for m in x_and_y]
testY=[m[1][-200:] for m in x_and_y]# 包含着真实的被分解的y
s_predy=[]

for i in range(allimfs.shape[0]):
    repetition(12, 1234, 2345)
    input_bilstm_cbams_shang = Input(batch_shape=(None,30,1))
    out_bilstm_cbams_shang = network_bilstm_cbams_shang(input_bilstm_cbams_shang,n)
    bilstm_cbams_shang = Model(inputs=input_bilstm_cbams_shang, outputs=out_bilstm_cbams_shang)
    bilstm_cbams_shang.compile(loss='mse', optimizer='adam', metrics=['mape'])
    bilstm_cbams_shang.fit(np.array(trainX[i]).reshape((-1,30,1)),np.array(trainY[i]),shuffle=False, verbose=1,batch_size=128, epochs=200)
    bilstm_cbams_shang_y = bilstm_cbams_shang.predict(np.array(testX[i]).reshape((-1, 30, 1)))
    bilstm_cbams_shang_y.ravel()
    bilstm_cbams_shang_list_y = list(bilstm_cbams_shang_y.ravel())#被预测的子序列
    s_predy.append(bilstm_cbams_shang_list_y)

predy=np.sum(s_predy,axis=0)
r2 = r2_score(np.array(test_y).ravel(), predy.ravel())
mape = np.mean(
    np.abs(np.array(test_y).ravel() - predy.ravel()) / (np.abs(np.array(test_y).ravel()) + 10 ** (-7)))
mae = mean_absolute_error(np.array(test_y).ravel(), predy.ravel())
rmse = (mean_squared_error(np.array(test_y).ravel(), predy.ravel())) ** 0.5
b=datetime.datetime.now()
time=(b-a).seconds
memory=psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024 / 1024
print(u'当前进程的内存使用：%.4f GB' % (psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024 / 1024))
print(r2,mape,mae,rmse)

df_de_em_shang=pd.DataFrame([list(np.array(test_y).ravel()),list(predy.ravel())]+s_predy).T
df_de_em_shang.columns=['real','de_em']+['imf'+str(i) for i in range(len(s_predy))]
df_de_em_shang.to_csv('eng/ceemdan/ceemdan_y.csv',index=False)

res=[r2,mape,mae,rmse,time,memory]
de_em_shang_res=pd.DataFrame(res).T
de_em_shang_res.columns=["r2","mape","mae","rmse","time","memory"]
de_em_shang_res.to_csv('eng/ceemdan/ceemdan_metric.csv',index=False)

l0=[i for i in testY]

ll=[[i[0] for i in l0[j]] for j in range(10)]

real=pd.DataFrame([[i[0] for i in test_y]]+ll).T
real.columns=["real"]+["imf"+str(i) for i in range(1,11)]
real.to_csv('eng/compare/real.csv',index=False)

just_0_1=pd.read_csv("eng/just_0_1.csv")
just_0_1.columns
from sklearn.metrics import f1_score
for i in just_0_1.columns:
    print(f1_score(just_0_1["real"],just_0_1[i]))

seq_df=pd.DataFrame([data3.to_list()]+seq).T
seq_df.to_csv('eng/seq_vmd.csv',index=False)

# coding=utf-8
import numpy as np
from sklearn import metrics

# MAPE和SMAPE需要自己实现
def mape(y_true, y_pred):
    return np.mean(np.abs((y_pred - y_true) / y_true)) * 100

def smape(y_true, y_pred):
    return 2.0 * np.mean(np.abs(y_pred - y_true) / (np.abs(y_pred) + np.abs(y_true))) * 100

y_true = np.array([1.0, 5.0, 4.0, 3.0, 2.0, 5.0, -3.0])
y_pred = np.array([1.0, 4.5, 3.5, 5.0, 8.0, 4.5, 1.0])

# MSE
print(metrics.mean_squared_error(y_true, y_pred)) # 8.107142857142858
# RMSE
print(np.sqrt(metrics.mean_squared_error(y_true, y_pred))) # 2.847304489713536
# MAE
print(metrics.mean_absolute_error(y_true, y_pred)) # 1.9285714285714286
# MAPE
print(mape(y_true, y_pred)) # 76.07142857142858，即76%
# SMAPE
print(smape(y_true, y_pred)) # 57.76942355889724，即58%

bilstm=pd.read_csv('eng/compare/without_cbam.csv')
smape(np.array([i[0] for i in test_y]),np.array(bilstm.multi.to_list()))# 2.824155

bilstm.bilstm_shang_y.to_list()