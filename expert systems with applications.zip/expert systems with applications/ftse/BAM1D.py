import tensorflow as tf
from tensorflow.keras.layers import Layer

class ChannelAttention(Layer):
    def __init__(self, reduction=16):
        super(ChannelAttention, self).__init__()
        self.reduction = reduction

    def build(self, input_shape):
        channels = input_shape[-1]# 将通道维度固定为最后一个维度。
        # self.avg_pool = tf.keras.layers.GlobalAveragePooling2D()
        self.avg_pool = tf.keras.layers.GlobalAveragePooling1D()# 修改代码为一维，因为要处理时序问题
        self.fc = tf.keras.layers.Dense(channels // self.reduction, activation='relu')
        self.sigmoid = tf.keras.layers.Dense(channels, activation='sigmoid')

    def call(self, inputs):
        avg_pool = self.avg_pool(inputs)
        fc_out = self.fc(avg_pool)
        attention = self.sigmoid(fc_out)
        #return tf.expand_dims(tf.expand_dims(attention, axis=1), axis=1)
        return tf.expand_dims(attention, axis=1)# 修改代码为1维，因为此处处理的是时序问题

class SpatialAttention(Layer):
    def __init__(self):
        super(SpatialAttention, self).__init__()

    def build(self, input_shape):
        #self.conv = tf.keras.layers.Conv2D(filters=1, kernel_size=(1, 1), strides=(1, 1), padding='same')
        self.conv = tf.keras.layers.Conv1D(filters=1, kernel_size=1, strides=1, padding='same')# 修改代码为一维，因为要处理时序问题
        self.sigmoid = tf.keras.layers.Activation('sigmoid')

    def call(self, inputs):
        conv_out = self.conv(inputs)
        attention = self.sigmoid(conv_out)
        return attention

class BAM(Layer):
    def __init__(self, reduction=16):
        super(BAM, self).__init__()
        self.channel_attention = ChannelAttention(reduction=reduction)
        self.spatial_attention = SpatialAttention()

    def build(self, input_shape):
        pass

    def call(self, inputs):
        channel_attention = self.channel_attention(inputs)
        spatial_attention = self.spatial_attention(inputs)
        attention = tf.multiply(channel_attention, spatial_attention)
        return tf.multiply(inputs, attention)

