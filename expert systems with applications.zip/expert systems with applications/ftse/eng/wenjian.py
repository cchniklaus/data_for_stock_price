# 处理如何使用cbam的问题。
# 基础库
import pandas as pd
import numpy as np

# 用于画图
import matplotlib.pyplot as plt

# 用于搭建网络
import tensorflow as tf
from keras.models import *
from keras.layers import *
from keras.optimizers import *

# 用于评价模型
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 用于复现
import random as rn

# 消除警告
import warnings

warnings.filterwarnings("ignore")

from sklearn.metrics import mean_absolute_error  # MAE
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
import os
import CBAM1D
from keras import backend


def repetition(x=123, y=12345, z=1234):
    np.random.seed(x)
    rn.seed(y)
    session_conf = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
    tf.random.set_seed(z)
    sess = tf.compat.v1.Session(graph=tf.compat.v1.get_default_graph(), config=session_conf)
    tf.compat.v1.keras.backend.set_session(sess)
    return None


data = pd.read_csv('FTSE.csv')# 获取数据

# 简单分析每一年的数据量
ri=list(data['日期'])
s=[]
for j in [str(k) for k in range(1991,2022)]:
    l=[1 if isinstance(i,str) and j in i else 0 for i in ri]
    print(sum(l))
    s.append(sum(l))
print(sum(s)/len(s))# 每一年的数据量约为244。

#经过计算，计划使用半年的数据作为test，122个

# 计划使用2000个数据，时间截止到2020-08-31，经过计算对应的index分别为7973到9972，所以需要使用9973
data1 = data['收盘价'].iloc[7973:9973]
print(len(data1))# 获取目标数据成功。
# 判断data1中是否有nan
data1[data1.isnull() == True]
# 删除缺失值
data1 = data1.dropna()


x_max = data1.max()
x_min = data1.min()
data3 = (data1 - x_min) / (x_max - x_min)

# 选择使用60预测1，所以先将数据转化成这个样子
def transform_data(data, dim_x, dim_y=1):
    """
    data:需要使用list输入
    dim_x:顾名思义
    dim_y:顾名思义，默认为1
    return:经过转化之后的数据
    """
    x, y = [], []
    # 首先计算经过转化之后的样本个数
    # 一个样本的长度是dim_x+dim_y，但是数据是从0开始的，所以相差的距离是dim_x+dim_y-1
    index_n_samples = len(data) - 1 - (dim_x + dim_y - 1)  # len(data)-1表示最后一个元素的index
    # 如此方能计算出样本数的索引index
    for i in range(index_n_samples + 1):
        # range中的最后一个元素取不到，所以加1
        x.append(data[0 + i:dim_x + i])
        y.append(data[dim_x + i:dim_x + dim_y + i])
    # 如此方能完成转化
    return (x, y)

x, y = transform_data(data3.to_list(), 30)

def network_bilstm_cbams_shang(a_input, n):
    # n表示cbam的个数。
    cbam = CBAM1D.cbam_module(a_input)
    if n > 1:
        for _ in range(n - 1):
            cbam = CBAM1D.cbam_module(cbam)
    a1 = Bidirectional(LSTM(64, use_bias=True, return_sequences=False))(cbam)
    a5 = Dense(1)(a1)
    return a5


import vmdpy

# VDM参数
alpha = 60 * 2  # alpha和子序列个数k是相互配合使用的，需要找寻自适应求解超参数的算法
tau = 0  # 分量和与总量的差距
#K = 8  # 指定分解个数
DC = 0  # 指定第一个是趋势项
init = 1  # 指定均匀分布初始化
tol = 1e-7  # 误差阈值
K=9

(u, u_hat, omega) = vmdpy.VMD(data3.to_list(), alpha, tau, K, DC, init, tol)
seq = []
for i in range(K):
    seq.append(u[i])
x_and_y=[transform_data(j,30) for j in seq]

# 由于按照半年一个周期，所以经计算一共16个周期，其中一共运算9次
for i in range(0,8):
    # 对于未分解序列划分成训练集，验证集，测试集
    train_x, valida_x, test_x = x[(0+i)*130:130*(6+i)], x[130*(6+i):130*(7+i)], x[130*(7+i):130*(8+i)]
    train_y, valida_y, test_y = y[(0+i)*130:130*(6+i)], y[130*(6+i):130*(7+i)], y[130*(7+i):130*(8+i)]

    trainX = [m[0][(0+i)*130:130*(6+i)] for m in x_and_y]
    validaX = [m[0][130*(6+i):130*(7+i)] for m in x_and_y]
    testX = [m[0][130*(7+i):130*(8+i)] for m in x_and_y]

    trainY = [m[1][(0+i)*130:130*(6+i)] for m in x_and_y]
    validaY = [m[1][130*(6+i):130*(7+i)] for m in x_and_y]
    testY = [m[1][130*(7+i):130*(8+i)] for m in x_and_y]  # 包含着真实的被分解的y

    save_r2 = []  # 根据r2选择模型
    save_model = []
    for j in range(1,6):
        repetition(12, 1234, 2345)  # 0.944955,0.0271
        input_bilstm_cbams_shang = Input(batch_shape=(None, 30, K))
        out_bilstm_cbams_shang = network_bilstm_cbams_shang(input_bilstm_cbams_shang, j)
        bilstm_cbams_shang = Model(inputs=input_bilstm_cbams_shang, outputs=out_bilstm_cbams_shang)
        bilstm_cbams_shang.compile(loss='mse', optimizer='adam', metrics=['mape'])
        bilstm_cbams_shang.fit(np.concatenate([np.array(i).reshape((-1,30,1)) for i in trainX], axis=-1),np.array(train_y)
                               , shuffle=False, verbose=1,
                               validation_data=(np.concatenate([np.array(i).reshape((-1,30,1)) for i in validaX], axis=-1), np.array(valida_y)),
                               batch_size=64, epochs=200)
        save_model.append(bilstm_cbams_shang)
        bilstm_cbams_shang_y = bilstm_cbams_shang.predict(np.concatenate([np.array(i).reshape((-1,30,1)) for i in validaX], axis=-1))
        bilstm_cbams_shang_y.ravel()
        bilstm_cbams_shang_list_y = list(bilstm_cbams_shang_y.ravel())
        # bilstm_cbams_shang_predict_y = pd.DataFrame(bilstm_cbams_shang_list_y)
        # bilstm_cbams_shang_predict_y.columns = ['bilstm_cbams_shang'+signal+'_y']
        # bilstm_cbams_shang_predict_y.to_csv('bilstm_cbams_shang'+signal+'_y.csv', index=False)
        r2 = r2_score(np.array(valida_y).ravel(), bilstm_cbams_shang_y.ravel())
        save_r2.append(r2)
    print(save_r2)
    num = save_r2.index(max(save_r2))
    best_model = save_model[num]
    # 获取y
    bilstm_cbams_shang_y = best_model.predict(np.concatenate([np.array(i).reshape((-1,30,1)) for i in testX], axis=-1))
    bilstm_cbams_shang_y.ravel()
    bilstm_cbams_shang_list_y = list(bilstm_cbams_shang_y.ravel())
    bilstm_cbams_shang_predict_y = pd.DataFrame([list(np.array(test_y).ravel()),bilstm_cbams_shang_list_y]).T
    bilstm_cbams_shang_predict_y.columns = ['real_y','bilstm_cbams_y']
    bilstm_cbams_shang_predict_y.to_csv('eng/wenjian/bilstm_cbams' + str(num+1) +'_'+str(i)+'_y.csv', index=False)

    # 获取metrics

    r2 = r2_score(np.array(test_y).ravel(), bilstm_cbams_shang_y.ravel())
    mape = np.mean(np.abs(np.array(test_y).ravel() - bilstm_cbams_shang_y.ravel()) / (
                np.abs(np.array(test_y).ravel()) + 10 ** (-7)))
    mae = mean_absolute_error(np.array(test_y).ravel(), bilstm_cbams_shang_y.ravel())
    rmse = (mean_squared_error(np.array(test_y).ravel(), bilstm_cbams_shang_y.ravel())) ** 0.5
    print('r2是%f，mape是%f，mae是%f，rmse是%f' % (r2, mape, mae, rmse))
    # 0.944955,0.027178,0.010828,0.013692

    # 保存运算结果
    bilstm_shang_metrics = pd.DataFrame([r2, mape, mae, rmse]).T
    bilstm_shang_metrics.columns = ['r2', 'mape', 'mae', 'rmse']
    bilstm_shang_metrics.to_csv('eng/wenjian/bilstm_cbams' + str(num+1)+'_'+str(i)+'_metrics.csv', index=False)