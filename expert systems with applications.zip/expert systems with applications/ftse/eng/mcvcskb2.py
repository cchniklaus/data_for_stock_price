import datetime
a=datetime.datetime.now()

import psutil
# 处理如何使用cbam的问题。
# 基础库
import pandas as pd
import numpy as np

# 用于画图
import matplotlib.pyplot as plt

# 用于搭建网络
import tensorflow as tf
from keras.models import *
from keras.layers import *
from keras.optimizers import *

# 用于评价模型
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 用于复现
import random as rn

# 消除警告
import warnings

warnings.filterwarnings("ignore")

from sklearn.metrics import mean_absolute_error  # MAE
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
import os
import CBAM1D
from keras import backend

def gk_ou(train_x,test_x,h=2):
    """
    建议数据在输入之前进行归一化处理
    :param train_x: 训练的x，输入要考虑使用array
    :param test_x: 要预测的x，同上
    :param h: 窗宽参数
    :return: 高斯距离
    """
    import numpy as np
    gaosi2=[]
    for i in range(train_x.shape[0]):
        gaosi2.append(np.linalg.norm(train_x[i]-test_x))
    max_=max(gaosi2)
    min_=min(gaosi2)
    maxmin_gaosi2=[(j-min_+10**(-5))/(max_-min_) for j in gaosi2]# 完成归一化处理
    w_gaosi=[np.exp(-0.5*h*s) for s in maxmin_gaosi2]
    return w_gaosi
# h的选择是一个问题，分析不同h下的影响。
def ek_ou(train_x, test_x):
    # q是控制窗宽参数的分位点参数，其余和ou_gk相同，q是1到100的整数输入。
    # q越大，h越大；h越大，被排除的样本就越少。
    results = []
    for i in range(train_x.shape[0]):
        s = train_x[i]  # 获得对比样本
        results.append(np.linalg.norm(test_x - s))  # 获得欧氏距离下的相似度度量
    np_r=np.array(results)
    l=np.percentile(np_r,25)
    h=np.percentile(np_r,75)
    v=h+1.5*(h-l)
    # 根据上面的结果获取h
    mm_results = [x if x<v else 0 for x in results]  # 筛除样本，距离较大的赋予0
    # 获取此时除0之外的最小值，与最大值
    # 利用list.copy()和filter
    copy_mm_results = mm_results.copy()

    del_0 = list(filter(lambda x: x != 0, copy_mm_results))
    x_max = max(del_0)
    x_min = min(del_0)

    # 对mm_results中的元素处理，如果是0，保持不动，非0，则归一化
    mm_results1 = list(
        map(lambda x: x if x == 0 else (x - x_min + 10 ** (-5)) / (x_max - x_min + 10 ** (-5)), mm_results))
    # 处理成功
    return mm_results1

# 感觉可以根据统计中的显著性水平设置排除5%的样本，尝试95.

def qk_ou(train_x, test_x):
    r = ek_ou(train_x, test_x)  # 此时r是一个list，且里面的元素分成两类，一类是0，一类是非0的需要计算平方的数值。
    re = list(map(lambda x: x ** 2 if x != 0 else 0, r))
    return re
# 设置95

def uk_ou(train_x, test_x):
    r = ek_ou(train_x, test_x)  # 此时r是一个list，且里面的元素分成两类，一类是0，一类是非0的需要返回1。
    re = list(map(lambda x: 1 if x != 0 else 0, r))
    return re

# 计算余弦的情况。
def gk_yu(train_x, test_x, h=2):
    from scipy import spatial
    import math
    # h是窗宽参数，标量
    # x是训练样本，二维
    # x0是目标样本，一维
    # 输出是一个list，在使用在模型的参数时注意添加np.array
    results = []
    for i in range(train_x.shape[0]):
        s = train_x[i]  # 获得对比样本
        results.append(0.5*(1 - spatial.distance.cosine(test_x, s)))  # 获得欧氏距离下的相似度度量
    # 进行归一化处理
    f_mm_results = [math.exp(-0.5 * h * j) for j in results]  # 得到最终的结果
    return f_mm_results
# h=2效果最好。# 余弦距离下的高斯函数不具有区分能力，故不适用。

# 对于存在筛选样本的核函数，其工作原理是首先根据示性函数筛选样本，然后将样本中未被
# 筛选下来的样本距离再做一次归一化。
def ek_yu(train_x, test_x):
    from scipy import spatial
    import math
    # q是控制窗宽参数的分位点参数，其余和ou_gk相同，q是1到100的整数输入。
    results = []
    for i in range(train_x.shape[0]):
        s = x[i]  # 获得对比样本
        results.append(0.5*(1 - spatial.distance.cosine(test_x, s)))  # 获得欧氏距离下的相似度度量
    np_r=np.array(results)
    l=np.percentile(np_r,25)
    h=np.percentile(np_r,75)
    v=h+1.5*(h-l)
    # 根据上面的结果获取h
    mm_results1 = [x if x<v else 0 for x in results]  # 筛除样本，距离较大的赋予0
    # 获取此时除0之外的最小值，与最大值
    # 利用list.copy()和filter
    copy_mm_results1 = mm_results1.copy()

    del_0 = list(filter(lambda x: x != 0, copy_mm_results1))
    x_max = max(del_0)
    x_min = min(del_0)

    # 对mm_results1中的元素处理，如果是0，保持不动，非0，则归一化
    mm_results2 = list(
        map(lambda x: x if x == 0 else (x - x_min + 10 ** (-5)) / (x_max - x_min + 10 ** (-5)), mm_results1))
    # 处理成功
    return mm_results2
#plt.plot(uk_yu(np.array(train_x),np.array(test_x)[0],95))

def qk_yu(train_x, test_x):
    r = ek_yu(train_x, test_x)  # 此时r是一个list，且里面的元素分成两类，一类是0，一类是非0的需要计算平方的数值。
    re = list(map(lambda x: x ** 2 if x != 0 else 0, r))
    return re


def uk_yu(train_x, test_x):
    r = ek_yu(train_x, test_x)  # 此时r是一个list，且里面的元素分成两类，一类是0，一类是非0的需要返回1。
    re = list(map(lambda x: 1 if x != 0 else 0, r))
    return re


def repetition(x=123, y=12345, z=1234):
    np.random.seed(x)
    rn.seed(y)
    session_conf = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
    tf.random.set_seed(z)
    sess = tf.compat.v1.Session(graph=tf.compat.v1.get_default_graph(), config=session_conf)
    tf.compat.v1.keras.backend.set_session(sess)
    return None


data = pd.read_csv('FTSE.csv')# 获取数据
# 计划使用2000个数据，时间截止到2020-08-31，经过计算对应的index分别为7973到9972，所以需要使用9973
data1 = data['收盘价'].iloc[7973:9973]
print(len(data1))# 获取目标数据成功。
# 判断data1中是否有nan
data1[data1.isnull() == True]
# 删除缺失值
data1 = data1.dropna()

x_max = data1.max()
x_min = data1.min()
data3 = (data1 - x_min) / (x_max - x_min)

# 选择使用60预测1，所以先将数据转化成这个样子
def transform_data(data, dim_x, dim_y=1):
    """
    data:需要使用list输入
    dim_x:顾名思义
    dim_y:顾名思义，默认为1
    return:经过转化之后的数据
    """
    x, y = [], []
    # 首先计算经过转化之后的样本个数
    # 一个样本的长度是dim_x+dim_y，但是数据是从0开始的，所以相差的距离是dim_x+dim_y-1
    index_n_samples = len(data) - 1 - (dim_x + dim_y - 1)  # len(data)-1表示最后一个元素的index
    # 如此方能计算出样本数的索引index
    for i in range(index_n_samples + 1):
        # range中的最后一个元素取不到，所以加1
        x.append(data[0 + i:dim_x + i])
        y.append(data[dim_x + i:dim_x + dim_y + i])
    # 如此方能完成转化
    return (x, y)

def network_bilstm_cbams_shang(a_input, n):
    # n表示cbam的个数。
    if n==0:
        a1 = Bidirectional(LSTM(64, use_bias=True, return_sequences=False))(a_input)
        a5 = Dense(1)(a1)
    else:
        cbam = CBAM1D.cbam_module(a_input)
        if n > 1:
            for _ in range(n - 1):
                cbam = CBAM1D.cbam_module(cbam)
        a1 = Bidirectional(LSTM(64, use_bias=True, return_sequences=False))(cbam)
        a5 = Dense(1)(a1)
    return a5



x, y = transform_data(data3.to_list(), 30)
# 划分成训练集，验证集，测试集
train_x, valida_x, test_x = x[:-400], x[-400:-200], x[-200:]
train_y, valida_y, test_y = y[:-400], y[-400:-200], y[-200:]

import vmdpy

# VDM参数
alpha = 60 * 2  # alpha和子序列个数k是相互配合使用的，需要找寻自适应求解超参数的算法
tau = 0  # 分量和与总量的差距
#K = 8  # 指定分解个数
DC = 0  # 指定第一个是趋势项
init = 1  # 指定均匀分布初始化
tol = 1e-7  # 误差阈值
K=10
n=2
(u, u_hat, omega) = vmdpy.VMD(data3.to_list(), alpha, tau, K, DC, init, tol)
seq = []
for i in range(K):
    seq.append(u[i])
x_and_y=[transform_data(j,30) for j in seq]

trainX=[m[0][:-400] for m in x_and_y]
validaX=[m[0][-400:-200] for m in x_and_y]
testX=[m[0][-200:] for m in x_and_y]

trainY=[m[1][:-400] for m in x_and_y]
validaY=[m[1][-400:-200] for m in x_and_y]
testY=[m[1][-200:] for m in x_and_y]# 包含着真实的被分解的y

pred_y=[]

for i in range(200):
    sw=np.array(uk_yu(np.array(train_x), np.array(test_x)[i]))
    repetition(12, 1234, 2345)
    input_bilstm_cbams_shang = Input(batch_shape=(None,30,K))
    out_bilstm_cbams_shang = network_bilstm_cbams_shang(input_bilstm_cbams_shang,n)
    bilstm_cbams_shang = Model(inputs=input_bilstm_cbams_shang, outputs=out_bilstm_cbams_shang)
    bilstm_cbams_shang.compile(loss='mse', optimizer='adam', metrics=['mape'])
    bilstm_cbams_shang.fit(np.concatenate([np.array(i).reshape((-1,30,1)) for i in trainX], axis=-1),np.array(train_y),shuffle=False, verbose=1,
                           batch_size=128, epochs=200,sample_weight=sw)
    bilstm_cbams_shang_y = bilstm_cbams_shang.predict(np.concatenate([np.array(i).reshape((-1, 30, 1)) for i in testX], axis=-1)[i].reshape((-1,30,K)))
    pred_y.append(bilstm_cbams_shang_y.ravel()[0])
    pd.DataFrame(pred_y).to_csv('eng/mcvcskb2/mcvcskb2_y_uk_yu.csv', index=False)
    print('-------------------------------第%d个样本已经完成预测和储存----------------------------------' % i)


r2 = r2_score(np.array(test_y).ravel(), pred_y)
mape = np.mean(
    np.abs(np.array(test_y).ravel() - pred_y) / (np.abs(np.array(test_y).ravel()) + 10 ** (-7)))
mae = mean_absolute_error(np.array(test_y).ravel(), pred_y)
rmse = (mean_squared_error(np.array(test_y).ravel(), pred_y)) ** 0.5

print(r2,mape,mae,rmse)

df_de_em_shang=pd.DataFrame([list(np.array(test_y).ravel()),pred_y]).T
df_de_em_shang.columns=['real','multi']
df_de_em_shang.to_csv('eng/mcvcskb2/mcvcskb2_y_uk_yu.csv',index=False)

res=[r2,mape,mae,rmse]
de_em_shang_res=pd.DataFrame(res).T
de_em_shang_res.columns=["r2","mape","mae","rmse"]
de_em_shang_res.to_csv('eng/mcvcskb2/mcvcskb2_metrics_uk_yu.csv',index=False)