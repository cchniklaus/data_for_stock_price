import datetime
a=datetime.datetime.now()

import psutil
# 处理如何使用cbam的问题。
# 基础库
import pandas as pd
import numpy as np

# 用于画图
import matplotlib.pyplot as plt

# 用于搭建网络
import tensorflow as tf
from keras.models import *
from keras.layers import *
from keras.optimizers import *

# 用于评价模型
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 用于复现
import random as rn

# 消除警告
import warnings

warnings.filterwarnings("ignore")

from sklearn.metrics import mean_absolute_error  # MAE
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
import os
import CBAM1D
from keras import backend


def repetition(x=123, y=12345, z=1234):
    np.random.seed(x)
    rn.seed(y)
    session_conf = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
    tf.random.set_seed(z)
    sess = tf.compat.v1.Session(graph=tf.compat.v1.get_default_graph(), config=session_conf)
    tf.compat.v1.keras.backend.set_session(sess)
    return None


data = pd.read_csv('FTSE.csv')# 获取数据
# 计划使用2000个数据，时间截止到2020-08-31，经过计算对应的index分别为7973到9972，所以需要使用9973
data1 = data['收盘价'].iloc[7973:9973]
print(len(data1))# 获取目标数据成功。
# 判断data1中是否有nan
data1[data1.isnull() == True]
# 删除缺失值
data1 = data1.dropna()

x_max = data1.max()
x_min = data1.min()
data3 = (data1 - x_min) / (x_max - x_min)

# 选择使用60预测1，所以先将数据转化成这个样子
def transform_data(data, dim_x, dim_y=1):
    """
    data:需要使用list输入
    dim_x:顾名思义
    dim_y:顾名思义，默认为1
    return:经过转化之后的数据
    """
    x, y = [], []
    # 首先计算经过转化之后的样本个数
    # 一个样本的长度是dim_x+dim_y，但是数据是从0开始的，所以相差的距离是dim_x+dim_y-1
    index_n_samples = len(data) - 1 - (dim_x + dim_y - 1)  # len(data)-1表示最后一个元素的index
    # 如此方能计算出样本数的索引index
    for i in range(index_n_samples + 1):
        # range中的最后一个元素取不到，所以加1
        x.append(data[0 + i:dim_x + i])
        y.append(data[dim_x + i:dim_x + dim_y + i])
    # 如此方能完成转化
    return (x, y)

def network_bilstm_cbams_shang(a_input, n):
    # n表示cbam的个数。
    if n==0:
        a1 = Bidirectional(LSTM(64, use_bias=True, return_sequences=False))(a_input)
        a5 = Dense(1)(a1)
    else:
        cbam = CBAM1D.cbam_module(a_input)
        if n > 1:
            for _ in range(n - 1):
                cbam = CBAM1D.cbam_module(cbam)
        a1 = Bidirectional(LSTM(64, use_bias=True, return_sequences=False))(cbam)
        a5 = Dense(1)(a1)
    return a5



x, y = transform_data(data3.to_list(), 30)
# 划分成训练集，验证集，测试集
train_x, valida_x, test_x = x[:-400], x[-400:-200], x[-200:]
train_y, valida_y, test_y = y[:-400], y[-400:-200], y[-200:]

import vmdpy

# VDM参数
alpha = 60 * 2  # alpha和子序列个数k是相互配合使用的，需要找寻自适应求解超参数的算法
tau = 0  # 分量和与总量的差距
#K = 8  # 指定分解个数
DC = 0  # 指定第一个是趋势项
init = 1  # 指定均匀分布初始化
tol = 1e-7  # 误差阈值
K=9
n=4
(u, u_hat, omega) = vmdpy.VMD(data3.to_list(), alpha, tau, K, DC, init, tol)
seq = []
for i in range(K):
    seq.append(u[i])
x_and_y=[transform_data(j,30) for j in seq]

trainX=[m[0][:-400] for m in x_and_y]
validaX=[m[0][-400:-200] for m in x_and_y]
testX=[m[0][-200:] for m in x_and_y]

trainY=[m[1][:-400] for m in x_and_y]
validaY=[m[1][-400:-200] for m in x_and_y]
testY=[m[1][-200:] for m in x_and_y]# 包含着真实的被分解的y



repetition(12, 1234, 2345)
input_bilstm_cbams_shang = Input(batch_shape=(None,30,K))
out_bilstm_cbams_shang = network_bilstm_cbams_shang(input_bilstm_cbams_shang,n)
bilstm_cbams_shang = Model(inputs=input_bilstm_cbams_shang, outputs=out_bilstm_cbams_shang)
bilstm_cbams_shang.compile(loss='mse', optimizer='adam', metrics=['mape'])
bilstm_cbams_shang.fit(np.concatenate([np.array(i).reshape((-1,30,1)) for i in trainX], axis=-1),np.array(train_y),shuffle=False, verbose=1,batch_size=128, epochs=200)
bilstm_cbams_shang_y = bilstm_cbams_shang.predict(np.concatenate([np.array(i).reshape((-1, 30, 1)) for i in testX], axis=-1))
bilstm_cbams_shang_y.ravel()
bilstm_cbams_shang_list_y = list(bilstm_cbams_shang_y.ravel())#被预测的子序列


r2 = r2_score(np.array(test_y).ravel(), bilstm_cbams_shang_y.ravel())
mape = np.mean(
    np.abs(np.array(test_y).ravel() - bilstm_cbams_shang_y.ravel()) / (np.abs(np.array(test_y).ravel()) + 10 ** (-7)))
mae = mean_absolute_error(np.array(test_y).ravel(), bilstm_cbams_shang_y.ravel())
rmse = (mean_squared_error(np.array(test_y).ravel(), bilstm_cbams_shang_y.ravel())) ** 0.5
b=datetime.datetime.now()
time=(b-a).seconds
memory=psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024 / 1024
print(u'当前进程的内存使用：%.4f GB' % (psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024 / 1024))
print(r2,mape,mae,rmse)

df_de_em_shang=pd.DataFrame([list(np.array(test_y).ravel()),list(bilstm_cbams_shang_y.ravel())]).T
df_de_em_shang.columns=['real','multi']
df_de_em_shang.to_csv('eng/compare/without_cbam.csv',index=False)

res=[r2,mape,mae,rmse,time,memory]
de_em_shang_res=pd.DataFrame(res).T
de_em_shang_res.columns=["r2","mape","mae","rmse","time","memory"]
de_em_shang_res.to_csv('eng/compare/without_cbam_metrics.csv',index=False)