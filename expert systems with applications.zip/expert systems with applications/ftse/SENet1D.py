import keras
from keras.layers import *
def se_block(input_feature, ratio=16):
    # “channels_first”或“channels_last”，则代表数据的通道维的位置（样本，通道，高，宽）
    # 上面是原始的结果，此处将其修改为通道放置于最后，因为要处理时序问题
    # channel_axis = 1 if K.image_data_format() == "channels_first" else -1
    channel_axis = -1  # 此处为增加的新代码，固定通道置于最后。
    # 获取输入通道数
    # channel = input_feature._keras_shape[channel_axis]
    channel = input_feature.shape[channel_axis]# 修改代码，将_keras_shape变成shape
    # 进行全局平均池化
    # se_feature = GlobalAveragePooling2D()(input_feature)
    se_feature = GlobalAveragePooling1D()(input_feature)  # 此处为增加的新代码，修改为1维，因为要处理时序问题。
    # 展开成一列
    # se_feature = Reshape((1, 1, channel))(se_feature)
    se_feature = Reshape((1, channel))(se_feature)  # 此处为增加的新代码，修改为1维，因为要处理时序问题。
    # 注意，默认不处理样本维度。因为batch_size=None

    # 压缩
    se_feature = Dense(channel // ratio,
                       activation='relu',
                       kernel_initializer='he_normal',
                       use_bias=True,
                       bias_initializer='zeros')(se_feature)
    # 激励
    se_feature = Dense(channel,
                       activation='sigmoid',
                       kernel_initializer='he_normal',
                       use_bias=True,
                       bias_initializer='zeros'
                       )(se_feature)

    # 维度置换，不包含样本维度，索引从1开始。
    """
    if K.image_data_format() == 'channels_first':
      se_feature = Permute((3, 1, 2))(se_feature)
    """
    # 此处不需要置换，因为要处理时序问题

    se_feature = multiply([input_feature, se_feature])

    return se_feature