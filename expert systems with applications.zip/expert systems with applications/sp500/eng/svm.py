

# 处理如何使用cbam的问题。
# 基础库
import pandas as pd
import numpy as np

# 用于画图
import matplotlib.pyplot as plt



# 用于评价模型
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 用于复现
import random as rn

# 消除警告
import warnings

warnings.filterwarnings("ignore")

from sklearn.metrics import mean_absolute_error  # MAE
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
import os

from keras import backend





data = pd.read_csv('eng/sp500.csv')# 获取数据
# 计划使用2000个数据，时间截止到2020-08-31，经过计算对应的index分别为14735到16735，所以需要使用16736
data1 = data['收盘价'].iloc[14735:16735]
print(len(data1))# 获取目标数据成功。
# 判断data1中是否有nan
data1[data1.isnull() == True]
# 删除缺失值
data1 = data1.dropna()

x_max = data1.max()
x_min = data1.min()
data3 = (data1 - x_min) / (x_max - x_min)
maxmin=pd.DataFrame([x_max,x_min])
maxmin.to_csv("eng/sp500_maxmin.csv",index=False)

def transform_data(data, dim_x, dim_y=1):
    """
    data:需要使用list输入
    dim_x:顾名思义
    dim_y:顾名思义，默认为1
    return:经过转化之后的数据
    """
    x, y = [], []
    # 首先计算经过转化之后的样本个数
    # 一个样本的长度是dim_x+dim_y，但是数据是从0开始的，所以相差的距离是dim_x+dim_y-1
    index_n_samples = len(data) - 1 - (dim_x + dim_y - 1)  # len(data)-1表示最后一个元素的index
    # 如此方能计算出样本数的索引index
    for i in range(index_n_samples + 1):
        # range中的最后一个元素取不到，所以加1
        x.append(data[0 + i:dim_x + i])
        y.append(data[dim_x + i:dim_x + dim_y + i])
    # 如此方能完成转化
    return x, y


x, y = transform_data(data3.to_list(), 30)
# 划分成训练集，验证集，测试集
train_x, valida_x, test_x = x[:-400], x[-400:-200], x[-200:]
train_y, valida_y, test_y = y[:-400], y[-400:-200], y[-200:]

from sklearn.svm import SVR

bilstm_shang=SVR(C=0.5)# 默认参数结果挺不错。

bilstm_shang.fit(np.array(train_x),np.array(train_y))


bilstm_shang_y=bilstm_shang.predict(np.array(test_x))
bilstm_shang_y.ravel()
bilstm_shang_list_y=list(bilstm_shang_y.ravel())
bilstm_shang_predict_y=pd.DataFrame(bilstm_shang_list_y)
bilstm_shang_predict_y.columns=['rf_shang_y']
bilstm_shang_predict_y.to_csv('eng/svm/svm_shang_y.csv',index=False)


# 利用gru_list_y计算对应的指标
r2=r2_score(np.array(test_y).ravel(),bilstm_shang_y.ravel())
mape=np.mean(np.abs(np.array(test_y).ravel()-bilstm_shang_y.ravel())/(np.abs(np.array(test_y).ravel())+10**(-7)))
mae=mean_absolute_error(np.array(test_y).ravel(),bilstm_shang_y.ravel())
rmse=(mean_squared_error(np.array(test_y).ravel(),bilstm_shang_y.ravel()))**0.5
print('r2是%f，mape是%f，mae是%f，rmse是%f'%(r2,mape,mae,rmse))
# 0.944955,0.027178,0.010828,0.013692

# 保存运算结果
bilstm_shang_metrics=pd.DataFrame([r2,mape,mae,rmse]).T
bilstm_shang_metrics.columns=['r2','mape','mae','rmse']
bilstm_shang_metrics.to_csv('eng/svm/svm_shang_metrics.csv',index=False)